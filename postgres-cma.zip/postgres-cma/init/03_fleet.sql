-- init/03_fleet.sql
-- Fleet fueling table for truck refuels / telemetry analytics
CREATE TABLE IF NOT EXISTS fuel_station_transactions_fuel_other_transactions (
  transaction_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  registration_number TEXT NOT NULL,
  fueling_date TIMESTAMPTZ NOT NULL,
  fuel_volume_liters NUMERIC(12,3) NOT NULL CHECK (fuel_volume_liters >= 0),
  odometer_reading_km NUMERIC(12,1),
  unit_price NUMERIC(12,4),
  total_amount NUMERIC(12,2),
  fuel_type TEXT,
  station_name TEXT,
  station_city TEXT,
  driver_id TEXT,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_fuel_reg_date ON fuel_station_transactions_fuel_other_transactions (registration_number, fueling_date DESC);
CREATE INDEX IF NOT EXISTS idx_fuel_meta_gin ON fuel_station_transactions_fuel_other_transactions USING GIN (meta);
