-- init/02_cma_schema.sql
-- Minimal example schema (UTC everywhere via TIMESTAMPTZ)
CREATE TABLE IF NOT EXISTS organization (
  organization_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  name           TEXT NOT NULL UNIQUE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS doctor (
  doctor_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organization(organization_id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  specialty TEXT,
  subroles  TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS patient (
  patient_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organization(organization_id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  pesel_encrypted   BYTEA,
  address_encrypted BYTEA,
  insurance JSONB,
  demographics JSONB,
  lifestyle JSONB,
  devices JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (jsonb_typeof(insurance) IS NULL OR jsonb_typeof(insurance) = 'object')
);

CREATE TABLE IF NOT EXISTS doctor_patient (
  doctor_id  BIGINT NOT NULL REFERENCES doctor(doctor_id) ON DELETE CASCADE,
  patient_id BIGINT NOT NULL REFERENCES patient(patient_id) ON DELETE CASCADE,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (doctor_id, patient_id)
);

CREATE TABLE IF NOT EXISTS measurement (
  measurement_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  patient_id BIGINT NOT NULL REFERENCES patient(patient_id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  value JSONB NOT NULL,
  measured_at TIMESTAMPTZ NOT NULL,
  source TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
) PARTITION BY RANGE (measured_at);

-- Example partition for current month; add more via migrations/cron
DO $$
DECLARE
  p_start date := date_trunc('month', now())::date;
  p_end   date := (date_trunc('month', now()) + interval '1 month')::date;
BEGIN
  EXECUTE format('CREATE TABLE IF NOT EXISTS measurement_%s_%s PARTITION OF measurement FOR VALUES FROM (%L) TO (%L);',
    to_char(p_start, 'YYYY'), to_char(p_start, 'MM'), p_start, p_end);
END $$;

CREATE INDEX IF NOT EXISTS idx_patient_org ON patient(organization_id);
CREATE INDEX IF NOT EXISTS idx_measurement_patient_time ON measurement (patient_id, measured_at DESC);

-- Optional app key for pgcrypto demo (store secrets elsewhere in prod!)
ALTER SYSTEM SET app.encryption_key = 'zmien_to_na_bezpieczny_klucz';
SELECT pg_reload_conf();
